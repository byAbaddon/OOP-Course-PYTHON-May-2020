from project.blade_knight import BladeKnight

class Tests(BladeKnight):
        def __init__(self, username, level):
            BladeKnight.__init__(self,username, level)


